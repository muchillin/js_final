
var  operando_a = "";
var  operando_b = "";
var  operacion = "";


var Calculadora = {
    init : function(){
     var display = document.getElementById('display')
     var on = document.getElementById("on")
     var sign = document.getElementById("sign")
     var raiz = document.getElementById("raiz")
     var dividido = document.getElementById("dividido")
     var siete = document.getElementById("7")
     var ocho = document.getElementById("8")
     var nueve = document.getElementById("9")
     var por = document.getElementById("por")
     var cuatro = document.getElementById("4")
     var cinco = document.getElementById("5")
     var seis = document.getElementById("6")
     var menos = document.getElementById("menos")
     var uno = document.getElementById("1")
     var dos = document.getElementById("2")
     var tres = document.getElementById("3")
     var cero = document.getElementById("0")
     var punto = document.getElementById("punto")
     var igual = document.getElementById("igual")
     var mas = document.getElementById("mas")

     cero.addEventListener("click",function(){
       numero("0");
       zoom(cero);
     })
     uno.addEventListener("click",function(){
       numero("1");
       zoom(uno);
     })
     dos.addEventListener("click",function(){
       numero("2");
       zoom(dos);
     })
     tres.addEventListener("click",function(){
       numero("3");
       zoom(tres);
     })
     cuatro.addEventListener("click",function(){
       numero("4");
       zoom(cuatro);
     })
     cinco.addEventListener("click",function(){
       numero("5");
       zoom(cinco);
     })
     seis.addEventListener("click",function(){
       numero("6");
       zoom(seis);
     })
     siete.addEventListener("click",function(){
       numero("7");
       zoom(siete);
     })
     ocho.addEventListener("click",function(){
       numero("8");
       zoom(ocho);
     })
     nueve.addEventListener("click",function(){
       numero("9");
       zoom(nueve);
     })
     mas.addEventListener("click",function(){
       zoom(mas);
     })
     menos.addEventListener("click",function(){
       zoom(menos);
     })
     dividido.addEventListener("click",function(){
       zoom(dividido);
     })
     por.addEventListener("click",function(){
       zoom(por);
     })
     on.addEventListener("click",function(){
       zoom(on);
     })
     sign.addEventListener("click",function(){
       zoom(sign);
     })
     punto.addEventListener("click",function(){
       zoom(punto);
     })
     igual.addEventListener("click",function(){
       zoom(igual);
     })
     //punto.addEventListener("click",function(){
       //numero(".")
     //})
//----------------------------------------------------------------------------
function numero (num){
if (display.textContent == "0"){
  display.textContent = "";
}

if (display.textContent.length < 8){
      display.textContent += num;
  }
}

//----------
     mas.onclick =function(e){
       operando_a = display.textContent;
       operacion="+";
       limpiar();
     }
     menos.onclick =function(e){
       operando_a = display.textContent;
       operacion="-";
       limpiar();
     }
     dividido.onclick =function(e){
       operando_a = display.textContent;
       operacion="/";
       limpiar();
     }
     por.onclick =function(e){
       operando_a = display.textContent;
       operacion="*";
       limpiar();
     }
//-----------
    sign.onclick = function(e){
      mame = parseFloat(display.textContent);
      mame *= -1;
      display.textContent = mame;
    }
//-------------
    punto.onclick =function(e){
      if (display.textContent.indexOf(".")==-1){
        display.textContent += ".";
      }
    }

//-----------
    on.onclick = function(e){
      display.textContent = "0";
    }

//-----------
    igual.onclick = function(e){
      operando_b = display.textContent;
      resolver();
    }

//-----------funciones
    function resolver (){
      var res = 0;
      switch (operacion){
        case "+" :
          res = parseFloat(operando_a) + parseFloat(operando_b);
          break;
        case "-" :
          res = parseFloat(operando_a) - parseFloat(operando_b);
          break;
        case "*" :
          res = parseFloat(operando_a) * parseFloat(operando_b);
          break;
        case "/" :
          res = parseFloat(operando_a) / parseFloat(operando_b);
          break;
        }
      resetear();
      display.textContent = res.toString();
    }
//-----------funciones

function zoom (valor){
valor.style.transform="scale(0.9)";
setTimeout(function(){ valor.style.transform="scale(1.0)"}, 100);
}

//-----------funciones
     function limpiar (){
         display.textContent="";
     }
//----------funciones
     function resetear (){
       display.innerHTML="";
       operando_a="";
       operando_b="";
       operacion=0;
     }
   }
}
Calculadora.init();
